/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ms3_1730700_simulatingoperrationofgulshanclub_v1;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author User50
 */
public class InvestorController implements Initializable {

    @FXML
    private Button Home;
    @FXML
    private Button Profile;
    @FXML
    private Button notice;
    @FXML
    private Button Queries;
    @FXML
    private Button Policy;
    @FXML
    private Button Reports;
    @FXML
    private Button ScheduleMeeting;
    @FXML
    private Button Event;
    @FXML
    private Button Facitities;
    @FXML
    private Button Reservations;
    @FXML
    private Button Reviews;
    @FXML
    private Button BookVenue;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
