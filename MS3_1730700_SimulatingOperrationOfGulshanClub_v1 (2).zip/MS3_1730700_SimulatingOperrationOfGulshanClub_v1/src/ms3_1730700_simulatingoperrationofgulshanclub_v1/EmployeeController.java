/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ms3_1730700_simulatingoperrationofgulshanclub_v1;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author User50
 */
public class EmployeeController implements Initializable {

    @FXML
    private VBox Vbox;
    @FXML
    private Button Home;
    @FXML
    private Button Profile;
    @FXML
    private Button Notice;
    @FXML
    private Button Queries;
    @FXML
    private Button Policy;
    @FXML
    private Button Reports;
    @FXML
    private Button LeaveApplicatin;
    @FXML
    private Button CreateInvoice;
    @FXML
    private Button Event;
    @FXML
    private Button Facilities;
    @FXML
    private Button Review;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
