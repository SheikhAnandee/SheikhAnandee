/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ms3_1730700_simulatingoperrationofgulshanclub_v1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author User50
 */
public class PresidentController implements Initializable {

    @FXML
    private Button Home;
    @FXML
    private VBox Vbox;
    @FXML
    private Button Profile;
    @FXML
    private Button Notice;
    @FXML
    private Button Queries;
    @FXML
    private Button ScheduleMeeting;
    @FXML
    private Button Policy;
    @FXML
    private Button Reports;
    @FXML
    private Button Event;
    @FXML
    private Button Facilities;
    @FXML
    private Button Reservations;
    @FXML
    private Button EmployeeList;
    @FXML
    private Button Reviews;
    @FXML
    private Button BookVenue;
    @FXML
    private BorderPane borderpane;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    

    @FXML
    private void sceduleMeetingBtnClicked(ActionEvent event) throws IOException {
        Parent root  = FXMLLoader.load(getClass().getResource("PresidentUI1.fxml"));
        borderpane.setCenter(root);
    }

    @FXML
    private void noticeBtnClicked(ActionEvent event) throws IOException {
        Parent root  = FXMLLoader.load(getClass().getResource("NoticeBoard.fxml"));
        borderpane.setCenter(root);
    }

    @FXML
    private void reportBtnClicked(ActionEvent event) throws IOException {
        Parent root  = FXMLLoader.load(getClass().getResource("PresidentReportUI.fxml"));
        borderpane.setCenter(root);
    }
    
}
